import React, { useState } from 'react';
import { WORKS_DATA, WorkItem } from '../data/worksData';
import { LITERARY_QUOTES } from '../data/examTipsData';
import {
  Sparkles,
  BookOpen,
  Send,
  Copy,
  Check,
  FileText,
  Quote,
  Flame,
  CheckCircle2,
} from 'lucide-react';

export const AiAssistantView: React.FC = () => {
  const [selectedWorkId, setSelectedWorkId] = useState<string>(WORKS_DATA[0].id);
  const [taskType, setTaskType] = useState<'intro' | 'outline' | 'devices' | 'connection' | 'social'>('outline');
  const [customPrompt, setCustomPrompt] = useState<string>('');
  const [outputResult, setOutputResult] = useState<string>('');
  const [isCopied, setIsCopied] = useState<boolean>(false);

  const selectedWork = WORKS_DATA.find((w) => w.id === selectedWorkId) || WORKS_DATA[0];

  const handleGenerate = () => {
    let result = '';

    if (taskType === 'intro') {
      result =
        `=== 3 CÁCH MỞ BÀI GIÁN TIẾP ẤN TƯỢNG CHO TÁC PHẨM "${selectedWork.title.toUpperCase()}" (${selectedWork.author.toUpperCase()}) ===\n\n` +
        `Cách 1: Mở bài bằng nhận định lý luận văn học\n` +
        `"Văn học là nhân học" (M. Gorki). Thật vậy, thiên chức cao cả của người nghệ sĩ không phải là xây dựng những lâu đài ngôn từ hư ảo, mà là cúi mình xuống nỗi đau và vẻ đẹp tâm hồn con người. Đến với "${selectedWork.title}" của ${selectedWork.author}, ta được đắm chìm trong bức tranh ${selectedWork.summary.toLowerCase()}, nơi ngòi bút tài hoa của tác giả đã tạc nên những giá trị nhân văn sâu sắc sống mãi với thời gian.\n\n` +
        `Cách 2: Mở bài từ đề tài và dòng chảy thời đại\n` +
        `Trong bản hợp xướng rực rỡ của văn học Việt Nam hiện đại, đề tài ${selectedWork.tag.toLowerCase()} luôn là mảnh đất màu mỡ khơi gợi bao nguồn cảm hứng. Ra đời vào năm ${selectedWork.year}, "${selectedWork.title}" của ${selectedWork.author} như một nốt nhạc ngân vang đầy độc đáo. Tác phẩm không chỉ phản ánh ${selectedWork.context} mà còn để lại ấn tượng sâu đậm trong lòng bao thế hệ độc giả.\n\n` +
        `Cách 3: Mở bài từ phong cách tác giả\n` +
        `${selectedWork.authorBio} Trong toàn bộ gia tài sáng tác của ông, "${selectedWork.title}" được xem là bông hoa kết tinh rực rỡ nhất của tài năng và tư tưởng. Đọc tác phẩm, người đọc như được đối thoại với một tâm hồn nghệ sĩ lớn, cùng rung động trước những vẻ đẹp vừa thiêng liêng vừa gần gũi.`;
    } else if (taskType === 'outline') {
      result =
        `=== DÀN Ý CHI TIẾT ĐẠT ĐIỂM 8.5+ CHO TÁC PHẨM "${selectedWork.title.toUpperCase()}" ===\n\n` +
        `I. MỞ BÀI (0.5 điểm):\n${selectedWork.essayOutline.introduction}\n\n` +
        `II. THÂN BÀI (3.5 - 4.0 điểm):\n` +
        `1. Khái quát hoàn cảnh và vị trí tác phẩm:\n- Hoàn cảnh sáng tác: ${selectedWork.context}\n- Cảm hứng chủ đạo: ${selectedWork.mainThemes[0]}\n\n` +
        selectedWork.essayOutline.body.map((b, i) => `${i + 2}. ${b}`).join('\n\n') +
        `\n\n* Đánh giá đặc sắc nghệ thuật:\n` +
        selectedWork.artisticValues.map((v) => `- ${v}`).join('\n') +
        `\n\nIII. KẾT BÀI (0.5 điểm):\n${selectedWork.essayOutline.conclusion}\n\n` +
        `* Nhận xét mở rộng/Nâng cao (Để đạt điểm 9+):\n` +
        `Liên hệ tư tưởng nhân đạo/lòng yêu nước với các tác phẩm cùng thời kỳ để khẳng định vị trí độc tôn của ${selectedWork.author} trong nền văn học dân tộc.`;
    } else if (taskType === 'devices') {
      result =
        `=== PHÂN TÍCH NGHỆ THUẬT & TRÍCH DẪN ĐẮT GIÁ CỦA "${selectedWork.title.toUpperCase()}" ===\n\n` +
        `1. Bút pháp nghệ thuật chủ đạo:\n` +
        selectedWork.artisticValues.map((v, i) => `• Điểm ${i + 1}: ${v}`).join('\n') +
        `\n\n2. Các câu trích dẫn "vàng ngọc" cần học thuộc:\n` +
        selectedWork.quotes.map((q, i) => `[${i + 1}] "${q}"`).join('\n\n') +
        `\n\n3. Chi tiết nghệ thuật đắt giá:\n` +
        `• Từ khóa then chốt: ${selectedWork.keywords.join(' · ')}\n` +
        `• Ý nghĩa: Mỗi chi tiết trong ${selectedWork.title} đều là sự kết tinh của tư tưởng nghệ thuật sâu sắc, vừa mang tính chân thực vừa giàu sức biểu tượng cao.`;
    } else if (taskType === 'connection') {
      const relatedQuote = LITERARY_QUOTES[Math.floor(Math.random() * LITERARY_QUOTES.length)];
      result =
        `=== LIÊN HỆ MỞ RỘNG & LÝ LUẬN VĂN HỌC CHO BÀI VIẾT VỀ "${selectedWork.title.toUpperCase()}" ===\n\n` +
        `1. Nhận định lý luận văn học áp dụng trực tiếp:\n` +
        `"${relatedQuote.quote}" - (${relatedQuote.author})\n` +
        `-> Cách đưa vào bài: ${relatedQuote.application}\n\n` +
        `2. Tác phẩm đối chiếu mở rộng tương đồng:\n` +
        `Khi phân tích về ${selectedWork.title}, học sinh nên liên hệ đối chiếu với các tác phẩm cùng giai đoạn như: Tây Tiến (Quang Dũng), Việt Bắc (Tố Hữu), Đất Nước (Nguyễn Khoa Điềm), hoặc Vợ chồng A Phủ (Tô Hoài).\n\n` +
        `3. Đúc kết tư tưởng thời đại:\n` +
        `Qua "${selectedWork.title}", ${selectedWork.author} đã góp một tiếng nói riêng biệt vào dòng chảy văn học yêu nước và nhân đạo của dân tộc, khơi dậy trong lòng thế hệ trẻ hôm nay niềm tự hào sâu sắc.`;
    } else if (taskType === 'social') {
      result =
        `=== GỢI Ý DẪN CHỨNG NGHỊ LUẬN XÃ HỘI (200 CHỮ) TỪ "${selectedWork.title.toUpperCase()}" ===\n\n` +
        `Tư tưởng cốt lõi của tác phẩm: ${selectedWork.mainThemes.join('; ')}\n\n` +
        `1. Đề tài tương thích: Lòng yêu nước, sự cống hiến, vượt lên nghịch cảnh, tình thương yêu đồng loại, lòng thủy chung.\n\n` +
        `2. Đoạn văn mẫu vận dụng dẫn chứng:\n` +
        `"Cuộc sống chỉ thực sự có ý nghĩa khi ta biết sống vì người khác và cống hiến cho những điều cao đẹp hơn bản thân mình. Tinh thần ấy khiến ta nhớ đến hình tượng trong tác phẩm '${selectedWork.title}' của ${selectedWork.author}. Giữa những năm tháng gian lao nhất, con người Việt Nam vẫn tỏa sáng với niềm tin bất diệt và lý tưởng sống cao cả. Ngày nay, tiếp bước thế hệ đi trước, thế hệ trẻ chúng ta cần không ngừng rèn luyện tri thức và phẩm cách để chung tay xây dựng đất nước vững bền."`;
    }

    if (customPrompt.trim()) {
      result += `\n\n---\n* Phản hồi câu hỏi riêng của bạn ("${customPrompt}"):\n` +
        `Với câu hỏi này, trọng tâm là bám sát văn bản ${selectedWork.title}, làm nổi bật tư tưởng của ${selectedWork.author} và dẫn chứng cụ thể từ các trích dẫn tiêu biểu.`;
    }

    setOutputResult(result);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(outputResult);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto px-3 sm:px-6 py-5 sm:py-8 space-y-6 sm:space-y-8 animate-in fade-in duration-300">
      {/* Title */}
      <div className="text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#f39c12]/15 border border-[#f39c12]/30 text-[#f39c12] text-xs font-semibold mb-3">
          <Sparkles className="w-4 h-4" />
          <span>Hệ Thống Trợ Lý Dàn Ý & Phân Tích Thông Minh</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-bold text-white font-display mb-2">
          Trợ Lý Văn Học 12
        </h2>
        <p className="text-slate-300 text-xs sm:text-sm max-w-xl mx-auto">
          Chọn tác phẩm và nhu cầu làm bài thi của bạn để nhận ngay gợi ý mở bài gián tiếp, dàn ý 8+, nghệ thuật và liên hệ lý luận văn học tức thì!
        </p>
      </div>

      {/* Control Box */}
      <div className="bg-[#16213e]/70 border border-white/10 rounded-2xl p-4 sm:p-8 space-y-5 sm:space-y-6 backdrop-blur-sm shadow-xl">
        {/* Step 1: Pick Work */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-2 uppercase tracking-wider">
            1. Chọn tác phẩm cần trợ giúp:
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {WORKS_DATA.map((w) => {
              const isSelected = w.id === selectedWorkId;
              return (
                <button
                  key={w.id}
                  type="button"
                  onClick={() => setSelectedWorkId(w.id)}
                  className={`p-2.5 rounded-xl text-xs font-medium text-left border transition-all truncate ${
                    isSelected
                      ? 'bg-[#e94560] text-white border-[#e94560] shadow-md font-semibold'
                      : 'bg-white/5 text-slate-300 border-white/5 hover:border-white/20 hover:text-white'
                  }`}
                  title={`${w.title} - ${w.author}`}
                >
                  <div className="truncate">{w.title}</div>
                  <div className="text-[10px] opacity-75 truncate">{w.author}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Step 2: Pick Task Type */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-2 uppercase tracking-wider">
            2. Bạn muốn trợ lý hỗ trợ nội dung gì?
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <button
              type="button"
              onClick={() => setTaskType('outline')}
              className={`p-3 rounded-xl text-xs font-medium border text-left transition-all ${
                taskType === 'outline'
                  ? 'bg-gradient-to-r from-[#e94560] to-[#c73659] text-white border-[#e94560] shadow-md'
                  : 'bg-white/5 text-slate-300 border-white/5 hover:border-white/20'
              }`}
            >
              <div className="font-bold flex items-center gap-1.5 mb-1">
                <FileText className="w-4 h-4 text-[#f39c12]" />
                <span>Dàn Ý 8.5+ Điểm</span>
              </div>
              <div className="text-[11px] opacity-80">Đầy đủ 3 phần & luận điểm chi tiết</div>
            </button>

            <button
              type="button"
              onClick={() => setTaskType('intro')}
              className={`p-3 rounded-xl text-xs font-medium border text-left transition-all ${
                taskType === 'intro'
                  ? 'bg-gradient-to-r from-[#e94560] to-[#c73659] text-white border-[#e94560] shadow-md'
                  : 'bg-white/5 text-slate-300 border-white/5 hover:border-white/20'
              }`}
            >
              <div className="font-bold flex items-center gap-1.5 mb-1">
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>3 Mở Bài Gián Tiếp</span>
              </div>
              <div className="text-[11px] opacity-80">Theo lý luận & phong cách tác giả</div>
            </button>

            <button
              type="button"
              onClick={() => setTaskType('devices')}
              className={`p-3 rounded-xl text-xs font-medium border text-left transition-all ${
                taskType === 'devices'
                  ? 'bg-gradient-to-r from-[#e94560] to-[#c73659] text-white border-[#e94560] shadow-md'
                  : 'bg-white/5 text-slate-300 border-white/5 hover:border-white/20'
              }`}
            >
              <div className="font-bold flex items-center gap-1.5 mb-1">
                <Quote className="w-4 h-4 text-emerald-400" />
                <span>Trích Dẫn & Nghệ Thuật</span>
              </div>
              <div className="text-[11px] opacity-80">Phân tích câu thơ vàng & bút pháp</div>
            </button>

            <button
              type="button"
              onClick={() => setTaskType('connection')}
              className={`p-3 rounded-xl text-xs font-medium border text-left transition-all ${
                taskType === 'connection'
                  ? 'bg-gradient-to-r from-[#e94560] to-[#c73659] text-white border-[#e94560] shadow-md'
                  : 'bg-white/5 text-slate-300 border-white/5 hover:border-white/20'
              }`}
            >
              <div className="font-bold flex items-center gap-1.5 mb-1">
                <Flame className="w-4 h-4 text-[#e94560]" />
                <span>Lý Luận & Liên Hệ Mở Rộng</span>
              </div>
              <div className="text-[11px] opacity-80">Ăn trọn 1đ câu hỏi phụ nhận xét</div>
            </button>

            <button
              type="button"
              onClick={() => setTaskType('social')}
              className={`p-3 rounded-xl text-xs font-medium border text-left transition-all ${
                taskType === 'social'
                  ? 'bg-gradient-to-r from-[#e94560] to-[#c73659] text-white border-[#e94560] shadow-md'
                  : 'bg-white/5 text-slate-300 border-white/5 hover:border-white/20'
              }`}
            >
              <div className="font-bold flex items-center gap-1.5 mb-1">
                <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                <span>Dẫn Chứng NLXH 200 Chữ</span>
              </div>
              <div className="text-[11px] opacity-80">Vận dụng tư tưởng tác phẩm vào đời sống</div>
            </button>
          </div>
        </div>

        {/* Optional Custom Request */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
            3. Yêu cầu hoặc đề bài cụ thể (tùy chọn):
          </label>
          <input
            type="text"
            value={customPrompt}
            onChange={(e) => setCustomPrompt(e.target.value)}
            placeholder="Ví dụ: Phân tích 14 câu đầu Tây Tiến, hoặc Cảm nhận vẻ đẹp người lính..."
            className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white placeholder-slate-400 text-xs sm:text-sm outline-none focus:border-[#e94560] transition-colors"
          />
        </div>

        {/* Generate Button */}
        <div>
          <button
            type="button"
            onClick={handleGenerate}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-[#e94560] via-[#c73659] to-[#f39c12] text-white font-bold text-sm shadow-[0_4px_20px_rgba(233,69,96,0.4)] hover:shadow-[0_6px_25px_rgba(233,69,96,0.6)] transition-all flex items-center justify-center gap-2 transform hover:-translate-y-0.5"
          >
            <Sparkles className="w-4 h-4" />
            <span>Tạo Gợi Ý Phân Tích Ngay</span>
          </button>
        </div>
      </div>

      {/* Output Result Container */}
      {outputResult && (
        <div className="bg-[#16213e]/80 border border-[#e94560]/40 rounded-2xl p-6 sm:p-8 space-y-4 backdrop-blur-sm shadow-2xl animate-in fade-in">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div className="flex items-center gap-2 text-white font-bold text-sm sm:text-base">
              <Sparkles className="w-5 h-5 text-[#f39c12]" />
              <span>Kết Quả Gợi Ý Từ Trợ Lý</span>
            </div>

            <button
              type="button"
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white/10 hover:bg-[#e94560] text-white transition-colors"
            >
              {isCopied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Đã sao chép!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Sao chép kết quả</span>
                </>
              )}
            </button>
          </div>

          <div className="p-4 rounded-xl bg-black/40 border border-white/5 text-xs sm:text-sm text-slate-200 whitespace-pre-line leading-relaxed font-sans max-h-[500px] overflow-y-auto">
            {outputResult}
          </div>
        </div>
      )}
    </div>
  );
};
